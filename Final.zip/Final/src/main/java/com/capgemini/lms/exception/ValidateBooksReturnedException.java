package com.capgemini.lms.exception;

public class ValidateBooksReturnedException extends Exception{
	public ValidateBooksReturnedException() {
		super();
		
	}

	public ValidateBooksReturnedException(String message) {
		super(message);
}
}