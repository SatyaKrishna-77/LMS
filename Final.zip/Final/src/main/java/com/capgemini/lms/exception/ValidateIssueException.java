package com.capgemini.lms.exception;

public class ValidateIssueException extends Exception{
	public ValidateIssueException() {
		super();
		
	}

	public ValidateIssueException(String message) {
		super(message);
		
	
	}
}

