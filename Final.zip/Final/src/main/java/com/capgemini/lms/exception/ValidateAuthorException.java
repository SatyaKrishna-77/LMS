package com.capgemini.lms.exception;

public class ValidateAuthorException extends Exception {
	public ValidateAuthorException() {
		super();
		
	}
	public ValidateAuthorException(String message) {
		super(message);	
	}
}

