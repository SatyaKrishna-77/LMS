package com.capgemini.lms.exception;

public class ValidateBooksException extends Exception{
	public ValidateBooksException() {
		super();
		
	}
	public ValidateBooksException(String message) {
		super(message);	
	}
}

