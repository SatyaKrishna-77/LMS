package com.capgemini.lms.repository;

import org.springframework.data.repository.CrudRepository;

import com.capgemini.lms.entities.Publishers;

public interface PublishersRepository extends CrudRepository<Publishers, Integer> {

}
