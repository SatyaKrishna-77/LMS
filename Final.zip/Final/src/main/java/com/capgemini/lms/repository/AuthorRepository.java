package com.capgemini.lms.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.capgemini.lms.entities.Author;

public interface AuthorRepository extends JpaRepository<Author, Integer>{


	

}
