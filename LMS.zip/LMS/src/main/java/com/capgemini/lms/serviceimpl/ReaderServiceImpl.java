package com.capgemini.lms.serviceimpl;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.lms.entities.Reader;
import com.capgemini.lms.exception.ReaderNotFoundException;
import com.capgemini.lms.service.ReaderService;
import com.capgemini.lms.repository.ReaderRepository;
import com.capgemini.lms.serviceimpl.*;

@Service
public class ReaderServiceImpl implements ReaderService {
	@Autowired
	ReaderRepository readerRepo;
	

	@Override
	public int register(Reader reader) throws ReaderNotFoundException {
		// TODO Auto-generated method stub
		try {
			readerRepo.save(reader);
		}catch(Exception e) {
			throw new ReaderNotFoundException("The passed object cannot be null");
		}
		return 0;
	
	}

	@Override
	public int updateReaderDetails(Reader reader) throws ReaderNotFoundException {
		// TODO Auto-generated method stub
		try {
			readerRepo.save(reader);
		}catch(Exception e) {
            throw new ReaderNotFoundException("The passed object cannot be null.");
        }
		return 0;
	
		}

	@Override
	public int deleteReader(int id) throws ReaderNotFoundException {
		try {
			readerRepo.deleteById(id);
		} catch (Exception e) {
			throw new ReaderNotFoundException("The object cannot be null");
		}
		return id;

	}

	@Override
	public List<Reader> viewReadersList() {
		
		return readerRepo.findAll();
	}

	@Override
	public Reader viewReaderById(int id) throws ReaderNotFoundException {
		Optional findById = Optional.empty();
		if(findById.isPresent()) {
			return (Reader) findById.get();
		}
		else {
			throw new ReaderNotFoundException("Reader with id :" + id + "doesn't exists");
		}

	}

	@Override
	public Reader loginValidate(String readerId, String password) throws ReaderNotFoundException {
		int i = Integer.parseInt(readerId);
		if(i == (new Reader().getId()) && password.equals(new Reader().getPassword())) {
				return readerRepo.save(new Reader());
			}
		
	    else {
			throw new ReaderNotFoundException("The entered id or password is wrong");
		}
		
}
}