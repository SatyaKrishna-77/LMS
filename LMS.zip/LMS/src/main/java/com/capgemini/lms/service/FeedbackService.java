package com.capgemini.lms.service;

import java.util.List;

import com.capgemini.lms.entities.Feedback;
import com.capgemini.lms.exception.FeedbackNotFoundException;

public interface FeedbackService {
	public int writeFeedback(Feedback feedback) throws FeedbackNotFoundException;
	public int updateFeedback(Feedback feedback) throws FeedbackNotFoundException;
	public List<Feedback> viewFeedbackList();
	public Feedback viewFeedBackByUser(int userid) throws FeedbackNotFoundException;
}
