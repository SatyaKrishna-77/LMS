package com.capgemini.lms.controller;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.MediaType;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;

import com.capgemini.lms.entities.Reader;
import com.capgemini.lms.entities.Reader;
import com.capgemini.lms.exception.AuthorNotFoundException;
import com.capgemini.lms.exception.ReaderNotFoundException;
import com.capgemini.lms.service.ReaderService;
import com.capgemini.lms.service.ReaderService;
@RestController
public class ReaderController {
	@Autowired
	ReaderService as;
	@GetMapping("/reader")
	private List<Reader> viewReadersList(){
		return as.viewReadersList();
	}
	@GetMapping("/reader/{id}")
	private List<Reader> viewReadersList(@PathVariable("id") int id){
		return as.viewReadersList();
	}
	@DeleteMapping("/reader/{id}")
	private int deleteReader(@PathVariable("id") int id) throws ReaderNotFoundException{
		return as.deleteReader(id);
	}
	@PostMapping("/reader")
	private int saveReader(@RequestBody Reader reader) throws ReaderNotFoundException {
		as.register(reader);
		return reader.getId();
	}
	@PutMapping("/updateReader")
	private Reader update(@RequestBody Reader reader) throws ReaderNotFoundException {
		as.updateReaderDetails(reader);
		return reader;
	}
}
