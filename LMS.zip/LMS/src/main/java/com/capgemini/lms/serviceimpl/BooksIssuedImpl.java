package com.capgemini.lms.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.capgemini.lms.entities.BooksIssued;
import com.capgemini.lms.exception.BookNotFoundException;
import com.capgemini.lms.repository.BooksIssuedRepository;
import com.capgemini.lms.service.BooksIssuedService;
@Service
public class BooksIssuedImpl implements BooksIssuedService {
	@Autowired
	BooksIssuedRepository booksIssuedRepository;

	@Override
	public int addIssuedBook(BooksIssued issued) {
		booksIssuedRepository.save(issued);
		return 0;
	}

	@Override
	public int updateIssuedBookDetails(BooksIssued booksIssued) {
		booksIssuedRepository.save(booksIssued);
		return 0;
	}

	
	public int deleteIssuedBookS(int bookid) throws BookNotFoundException {
		try {
			booksIssuedRepository.deleteById(bookid);
		} catch (Exception e) {
			throw new BookNotFoundException("The object cannot be null");
		}
		return bookid;
	}

	@Override
	public List<BooksIssued> viewBooksIssuedList() {
		 List<BooksIssued> result = new ArrayList<BooksIssued>();
	        booksIssuedRepository.findAll().forEach(author1 -> result.add(author1));
	        return result;
		
	}

}
