package com.capgemini.lms.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.lms.entities.Publishers;
import com.capgemini.lms.exception.PublisherNotFoundException;
import com.capgemini.lms.repository.PublishersRepository;
import com.capgemini.lms.service.PublisherService;

@Service
public class PublService implements PublisherService {
	
	@Autowired
	PublishersRepository publishersRepository;

	@Override
	public int addPublisher(Publishers publisher) throws PublisherNotFoundException {
		// TODO Auto-generated method stub
		try {
			publishersRepository.save(publisher);
		} catch(Exception e) {
			throw new PublisherNotFoundException("the passed object cannot be null");
		}
		return 0;
	}

	@Override
	public int updatePublisherDetails(Publishers publisher) throws PublisherNotFoundException {
		// TODO Auto-generated method stub
		try {
			publishersRepository.save(publisher);
		} catch(Exception e) {
			throw new PublisherNotFoundException("the passed object cannot be null");
		}
		return 0;
	}

	@Override
	public int removePublisher(int publisherId) throws PublisherNotFoundException {
		// TODO Auto-generated method stub
		try {
			publishersRepository.deleteById(publisherId);
		} catch(Exception e) {
			throw new PublisherNotFoundException("the object cannot be null");
		}
		return publisherId;
	}

	@Override
	public List<Publishers> viewPublishersList() {
		// TODO Auto-generated method stub
		List<Publishers> result = new ArrayList<Publishers>();
		publishersRepository.findAll().forEach(publisher1 -> result.add(publisher1));
		return result;
	}

	@Override
	public Publishers viewPublisherById(int id) throws PublisherNotFoundException {
		// TODO Auto-generated method stub
		try {
			return publishersRepository.findById(id).get();
		} catch(Exception e) {
			throw new PublisherNotFoundException("the object cannot be null");
		}
		//return null;
	}

}
