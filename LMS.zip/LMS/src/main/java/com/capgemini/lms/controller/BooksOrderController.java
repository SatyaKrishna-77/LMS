package com.capgemini.lms.controller;
import org.springframework.http.MediaType;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.lms.entities.Books;
//import com.capgemini.lms.entities.Author;
import com.capgemini.lms.entities.BooksOrder;
import com.capgemini.lms.exception.OrderNotFoundException;
//import com.capgemini.lms.serviceimpl.AuthService;
import com.capgemini.lms.serviceimpl.BooksOrderImpl;


@RestController

public class BooksOrderController {
	
			@Autowired
			BooksOrderImpl as;
			public  BooksOrderController(BooksOrderImpl bookimpl) {
				this.as = bookimpl;
			}
			@GetMapping(value = "/BooksOrder",produces=MediaType.APPLICATION_JSON_VALUE)
			private List<BooksOrder> viewOrdersList(){
				return as.viewOrdersList();
			}
			@GetMapping("/GetBooksOrder/{id}")
				private List<BooksOrder> viewOrdersList(@PathVariable("id") int orderId){
					return as.viewOrdersList();
				}
			
			@DeleteMapping("/DeleteBooksOrder/{BooksOrderId}")
			private int cancelOrder(@PathVariable("bookid") int id) throws OrderNotFoundException{
				return as.cancelOrder(id);
			}
			@PostMapping("/PostBooksOrder")
			private int placeBooksOrder(@RequestBody Books books) throws OrderNotFoundException {
				as.placeBooksOrder(books);
				return books.getBookid();
			}
			@PutMapping("/update")
			private BooksOrder update(@RequestBody BooksOrder BooksOrder) throws OrderNotFoundException {
				as.updateOrder(BooksOrder);
				return BooksOrder;
			}
			
		}