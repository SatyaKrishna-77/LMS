package com.capgemini.lms.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.capgemini.lms.entities.BooksIssued;
import com.capgemini.lms.exception.BookNotFoundException;

public interface BooksIssuedService {
	public int addIssuedBook(BooksIssued issued);
	public int updateIssuedBookDetails(BooksIssued booksIssued);
	public int deleteIssuedBookS(int bookid) throws BookNotFoundException;
	public List<BooksIssued> viewBooksIssuedList();
}

