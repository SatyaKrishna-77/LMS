package com.capgemini.lms.service;

import java.util.List;

import com.capgemini.lms.entities.Books;
import com.capgemini.lms.entities.DamagedBooks;
import com.capgemini.lms.exception.BookNotFoundException;

public interface DamagedBooksService {
	public int addDamagedBooks(Books bookid);
	public int updateDamagedBookDetails(DamagedBooks damagedbooks) throws BookNotFoundException;
	public List<DamagedBooks> viewDamagedBooksList();
	public DamagedBooks viewDamagedBookById(int id) throws BookNotFoundException;
}
