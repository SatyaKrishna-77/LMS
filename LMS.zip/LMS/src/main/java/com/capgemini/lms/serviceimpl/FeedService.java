package com.capgemini.lms.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.lms.entities.Feedback;
import com.capgemini.lms.exception.FeedbackNotFoundException;
import com.capgemini.lms.repository.FeedbackRepository;
import com.capgemini.lms.service.FeedbackService;

@Service
public class FeedService implements FeedbackService {
	@Autowired
	FeedbackRepository feedbackRepository;

	@Override
	public int writeFeedback(Feedback feedback) throws FeedbackNotFoundException {
		// TODO Auto-generated method stub
		try {
			feedbackRepository.save(feedback);
		} catch(Exception e) {
			throw new FeedbackNotFoundException("the passed object cannot be null");
		}
		return 0;
	}

	@Override
	public int updateFeedback(Feedback feedback) throws FeedbackNotFoundException {
		// TODO Auto-generated method stub
		try {
			feedbackRepository.save(feedback);
		} catch(Exception e) {
			throw new FeedbackNotFoundException("the passed object cannot be null");
		}
		return 0;
	}

	@Override
	public List<Feedback> viewFeedbackList() {
		// TODO Auto-generated method stub
		List<Feedback> result = new ArrayList<Feedback>();
		feedbackRepository.findAll().forEach(feedback1 -> result.add(feedback1));
		
		return result;
	}

	@Override
	public Feedback viewFeedBackByUser(int userid) throws FeedbackNotFoundException {
		// TODO Auto-generated method stub
		try {
			return feedbackRepository.findById(userid).get();
		} catch (Exception e) {
			throw new FeedbackNotFoundException("the passed object cannot be null");
		}
		//return null;
	}


}
