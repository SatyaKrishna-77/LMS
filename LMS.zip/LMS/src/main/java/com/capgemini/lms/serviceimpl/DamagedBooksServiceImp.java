package com.capgemini.lms.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import com.capgemini.lms.repository.DamagedBooksRepository;
import com.capgemini.lms.service.*;
import com.capgemini.lms.entities.Books;
import com.capgemini.lms.entities.DamagedBooks;
import com.capgemini.lms.exception.BookNotFoundException;
import org.springframework.stereotype.Service;
@Service
public class DamagedBooksServiceImp implements DamagedBooksService{
	DamagedBooksRepository damagedbookr;
	@Override
	public int addDamagedBooks(Books bookId)  {
		// TODO Auto-generated method stub
		damagedbookr.save(bookId);
		
		return 0;
	}

	@Override
	public int updateDamagedBookDetails(DamagedBooks damagedbooks) throws BookNotFoundException{
		// TODO Auto-generated method stub

		try {
			damagedbookr.save(damagedbooks);
		}catch(Exception e) {
            throw new BookNotFoundException("The passed object cannot be null.");
        }
		return 0;
	}

	@Override
	public List<DamagedBooks> viewDamagedBooksList() {
		// TODO Auto-generated method stub
		 List<DamagedBooks> result = new ArrayList<DamagedBooks>();
		 damagedbookr.findAll().forEach(book1 -> result.add(book1));
	        return result;
		
	}

	@Override
	public DamagedBooks viewDamagedBookById(int id) throws BookNotFoundException{
		// TODO Auto-generated method stub
		try {
			return  damagedbookr.findById(id).get();
		}catch(Exception e) {
            throw new BookNotFoundException("The passed object cannot be null.");
        }
		
		
	}

}
