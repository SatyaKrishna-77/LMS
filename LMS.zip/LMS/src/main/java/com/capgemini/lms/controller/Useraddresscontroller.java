package com.capgemini.lms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;
import com.capgemini.lms.entities.UserAddress;
import com.capgemini.lms.exception.AddressNotFoundException;
import com.capgemini.lms.serviceimpl.UserAddressimpl;
import org.springframework.http.MediaType;
import java.util.List;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

@RestController
public class Useraddresscontroller {
	@Autowired
    UserAddressimpl ua;
	@GetMapping(value="/UserAddress",produces=MediaType.APPLICATION_JSON_VALUE)
	private List<UserAddress> viewUserAddressList(){
		return ua.viewUserAddressList();
	}
	@GetMapping("/UserAddress/{id}")
	private List<UserAddress> viewUserAddressList(@PathVariable("id") int UserAddressId){
		return ua.viewUserAddressList();
	}
	@DeleteMapping("/UserAddress/{addressId}")
	private int deleteUserAddressDetails(@PathVariable("addressId") int addressId) throws AddressNotFoundException{
		return ua.deleteUserAddress(addressId);
	}
	@PostMapping("/UserAddress")
	private int saveUserAddress(@RequestBody UserAddress address) throws AddressNotFoundException {
		ua.addUserAddress(address);
		return address.getAddressId();
	}
	@PutMapping("/updateUserAddress")
	private int updateUserAddressDetails(@RequestBody UserAddress address) throws AddressNotFoundException {
		ua.updateUserAddressDetails(address);
		return 0;
	}
}
	

