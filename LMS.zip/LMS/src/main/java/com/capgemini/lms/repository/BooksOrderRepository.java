package com.capgemini.lms.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.capgemini.lms.entities.Books;
import com.capgemini.lms.entities.BooksOrder;

public interface BooksOrderRepository extends CrudRepository <BooksOrder, Integer>{

	void save(Books book);

	//void save(Books book);

	 //save (Books book);
	
		    //int cancelOrder(int orderId)
		    //int placeBooksOrder(Books book);
			//Author vieworderById(int id);
		    //int updateOrder(BooksOrder order)
			
			//List<BooksOrder> getAll();
	     // void saveAll(Books book);
		  

			

		}

