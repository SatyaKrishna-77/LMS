package com.capgemini.lms.serviceimpl;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.lms.entities.UserAddress;
import com.capgemini.lms.exception.AddressNotFoundException;
import com.capgemini.lms.repository.UserAddressRepository;
import com.capgemini.lms.service.UserAddressService;

@Service
public class UserAddressimpl implements UserAddressService{
	@Autowired
	UserAddressRepository useraddressrepository;

	@Override
	public int addUserAddress(UserAddress address) {
			useraddressrepository.save(address);
		return 0;
	}

	@Override
	public int updateUserAddressDetails(UserAddress address) throws AddressNotFoundException {
		try {
			useraddressrepository.save(address);
		}catch(Exception e) {
            throw new AddressNotFoundException("The passed object cannot be null.");
        }
		return 0;
	}

	@Override
	public int deleteUserAddress(int addressId) throws AddressNotFoundException {
		try {
			useraddressrepository.deleteById(addressId);
		} catch (Exception e) {
			throw new AddressNotFoundException("The object cannot be null");
		}
		return 0;
	}

	@Override
	public UserAddress viewAddressByUserId(int userid) throws AddressNotFoundException {
		try {
			return useraddressrepository.findById(userid).get();
		}catch(Exception e) {
			throw new AddressNotFoundException("The object cannot be null");
		}
	}

	@Override
	public List<UserAddress> viewUserAddressList() {
		List<UserAddress> result = new ArrayList<UserAddress>();
        useraddressrepository.findAll().forEach(UserAddress1 -> result.add(UserAddress1));
        return result;
	}

}
