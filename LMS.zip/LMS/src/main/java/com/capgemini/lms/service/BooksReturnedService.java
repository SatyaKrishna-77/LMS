package com.capgemini.lms.service;

import java.util.List;

import com.capgemini.lms.entities.BooksReturned;
import com.capgemini.lms.exception.BookNotFoundException;

public interface BooksReturnedService {
	public int returnBooks(BooksReturned returned);
	public int updateReturnedBookDetails(BooksReturned booksReturned) throws BookNotFoundException;
	public List<BooksReturned> viewReturnedBooksList();
	public List<BooksReturned> viewDelayedBooksList();
}
