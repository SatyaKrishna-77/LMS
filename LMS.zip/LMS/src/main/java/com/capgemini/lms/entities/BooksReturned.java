package com.capgemini.lms.entities;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Column;
@Entity(name="booksreturned")
@Table(name="booksreturned")
public class BooksReturned {
	@Id
	@Column(name = "Book_id")
//	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	@OneToOne(fetch = FetchType.EAGER)
	private Users users;
	@OneToMany(fetch = FetchType.LAZY)
	private List<Books> books;
	@Column(name = "Returned_Date")
	private Date returnedDate;
	@Column(name = "Delayed_Days")
	private int delayed_Days;
	@Column(name = "Penalty")
	private double penalty;
	@Column(name = "Penalty_Status")
	private String penalty_Status;
	public BooksReturned() {
		
	}
//	public BooksReturned(int id,Users users,Books books ,Date returnedDate, int delayed_Days, double penalty,String penalty_Status) {
//		super();
//		this.id = id;
//		this.users = users;
//		//this.books = books;
//		this.returnedDate = returnedDate;
//		this.delayed_Days = delayed_Days;
//		this.penalty = penalty;
//		this.penalty_Status = penalty_Status;
//	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Users getUsers() {
		return users;
	}
	public void setUsers(Users users) {
		this.users = users;
	}
	public List<Books> getBooks() {
		return books;
	}
	public void setBooks(List<Books> books) {
		this.books = books;
	}
	public Date getReturnedDate() {
		return returnedDate;
	}
	public void setReturnedDate(Date returnedDate) {
		this.returnedDate = returnedDate;
	}
	public int getDelayed_Days() {
		return delayed_Days;
	}
	public void setDelayed_Days(int delayed_Days) {
		this.delayed_Days = delayed_Days;
	}
	public double getPenalty() {
		return penalty;
	}
	public void setPenalty(double penalty) {
		this.penalty = penalty;
	}
	public String getPenalty_Status() {
		return penalty_Status;
	}
	public void setPenalty_Status(String penalty_Status) {
		this.penalty_Status = penalty_Status;
	}
@Override
public String toString() {
		return "BooksReturned [id=" + id + ", Users=" + users + ",Returned Date=" + returnedDate+",Delayed_Days="+delayed_Days+",Penalty =" +penalty+",Penalty status ="+penalty_Status+"]";
					
		}
}
