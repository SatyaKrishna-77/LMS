package com.capgemini.lms.serviceimpl;
import com.capgemini.lms.repository.BooksReturnedRepository;
import com.capgemini.lms.service.*;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//import com.capgemini.lms.entities.Author;
import com.capgemini.lms.entities.BooksReturned;
import com.capgemini.lms.exception.*;
@Service
public class BooksReturnedServiceImp implements BooksReturnedService{
	@Autowired
	BooksReturnedRepository brs;
	BooksReturned br;
	@Override
	public int returnBooks(BooksReturned returned) {
		// TODO Auto-generated method stub
		brs.save(returned);
		return 0;
	}
	@Override
	public int updateReturnedBookDetails(BooksReturned booksReturned) throws BookNotFoundException{
		// TODO Auto-generated method stub
		try {
			brs.save(booksReturned);
		}catch(Exception e) {
            throw new BookNotFoundException("The passed object cannot be null.");
        }
		return 0;
	}

	@Override
	public List<BooksReturned> viewReturnedBooksList() {
		// TODO Auto-generated method stub
		List<BooksReturned> result = new ArrayList<BooksReturned>();
        brs.findAll().forEach(booksreturned1 -> result.add(booksreturned1));
        return result;
		
	}

	@Override
	public List<BooksReturned> viewDelayedBooksList() {
		// TODO Auto-generated method stub
		List<BooksReturned> delayedbooks = new ArrayList<BooksReturned>();
		if (br.getDelayed_Days()>0) {
			for(BooksReturned book1:delayedbooks) {
				delayedbooks.add(book1);
			}return delayedbooks;
		}else{
			
		return null;}
	}

}
