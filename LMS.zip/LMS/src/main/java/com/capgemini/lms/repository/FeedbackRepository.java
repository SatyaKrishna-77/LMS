package com.capgemini.lms.repository;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.capgemini.lms.entities.Feedback;

public interface FeedbackRepository extends CrudRepository<Feedback, Integer>{

	//void save(int userid);

	//Optional<Feedback> findById(int userid);

}
