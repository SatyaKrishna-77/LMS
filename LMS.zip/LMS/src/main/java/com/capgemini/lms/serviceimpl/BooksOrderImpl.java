package com.capgemini.lms.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.lms.entities.Books;
//import com.capgemini.lms.entities.Author;
//import com.capgemini.lms.entities.Books;
import com.capgemini.lms.entities.BooksOrder;
import com.capgemini.lms.exception.AuthorNotFoundException;
import com.capgemini.lms.exception.OrderNotFoundException;
import com.capgemini.lms.repository.BooksOrderRepository;
import com.capgemini.lms.service.BooksOrderService;

import com.capgemini.lms.service.BooksOrderService;
@Service
public class BooksOrderImpl implements BooksOrderService {
	
		@Autowired
		BooksOrderRepository booksOrderRepository;

		
		public  int placeBooksOrder(Books book)  {
		 
			
				booksOrderRepository.save(book);
			return 0;
		}

		@Override
		public int cancelOrder(int orderId) throws OrderNotFoundException {
			try {
				booksOrderRepository.deleteById(orderId);
			}catch(Exception e) {
	            throw new OrderNotFoundException("The passed object cannot be null.");
	        }
			return 0;
		}

		@Override
		public int updateOrder(BooksOrder order) throws OrderNotFoundException {
			try {
				booksOrderRepository.save(order);
			}catch(Exception e) {
	            throw new OrderNotFoundException("The passed object cannot be null.");
	        }
			return 0;
		
		}

		@Override
		public List<BooksOrder> viewOrdersList() {
			 List<BooksOrder> result = new ArrayList<BooksOrder>();
		        booksOrderRepository.findAll().forEach(BooksOrder1 -> result.add(BooksOrder1));
		        return result;

		}

		@Override
		public BooksOrder viewOrderById(int orderId) throws OrderNotFoundException{
			try {
				return booksOrderRepository.findById(orderId).get();
			}catch(Exception e) {
				throw new OrderNotFoundException("The object cannot be null");
			}
		}

	}


