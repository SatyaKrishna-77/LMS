package com.capgemini.lms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.lms.entities.Feedback;
import com.capgemini.lms.exception.FeedbackNotFoundException;
import com.capgemini.lms.service.FeedbackService;
import com.capgemini.lms.serviceimpl.FeedService;
//import com.capgemini.lms.serviceimpl.FeedService;

@RestController
public class FeedbackController {
	
	@Autowired
	FeedService fs;
	
	@GetMapping(value = "/feedbacks", produces = MediaType.APPLICATION_JSON_VALUE)
	private List<Feedback> viewFeedbackList() {
		return fs.viewFeedbackList();
	}
	
	@GetMapping("getfeedback/{userid}")
	private List<Feedback> viewFeedbackList(@PathVariable("userid") int id) {
		return fs.viewFeedbackList();
	}
	
	@PostMapping("/savefeedback")
	//@ExceptionHandler(FeedbackNotFoundException.class)
	private void saveFeedback(@RequestBody Feedback feedback) throws FeedbackNotFoundException {
		fs.writeFeedback(feedback);
		//return userid.getId();
	}
	
	@PutMapping("/updatefeedback")
	private Feedback update(@RequestBody Feedback feedback) throws FeedbackNotFoundException {
		fs.updateFeedback(feedback);
		return feedback;
	}
	
	/*@Autowired
	FeedbackService fs;
	
	@GetMapping(value="/feedback",produces=MediaType.APPLICATION_JSON_VALUE)
	private List<Feedback> viewFeedbackList(){
		return fs.viewFeedbackList();
	}
	@GetMapping("/feedback/{id}")
	private List<Feedback> viewFeedbackList(@PathVariable("id") int userid){
		return fs.viewFeedbackList();
	}
	/*@DeleteMapping("/feedback/{feedbackId}")
	private int deleteFeedbackDetails(@PathVariable("feedbackId") int id) throws FeedbackNotFoundException{
		return fs.deleteFeedbackDetails(id);
	}*/
	/*@PostMapping("/feedback/{id}")
	private int saveFeedback(@PathVariable("id") int userid) throws FeedbackNotFoundException {
		return fs.writeFeedback(userid);
		//return String.valueOf(userid.getId());
		//return writeFeedback.getId();
	}
	@PutMapping("/update")
	private Feedback update(@RequestBody Feedback feedback) throws FeedbackNotFoundException {
		fs.updateFeedback(feedback);
		return feedback;
	}*/

}
