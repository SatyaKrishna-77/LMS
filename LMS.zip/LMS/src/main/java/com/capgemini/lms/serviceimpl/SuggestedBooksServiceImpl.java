package com.capgemini.lms.serviceimpl;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.capgemini.lms.entities.Books;
import com.capgemini.lms.entities.Reader;
import com.capgemini.lms.entities.SuggestedBooks;
import com.capgemini.lms.exception.BookNotFoundException;
import com.capgemini.lms.exception.ReaderNotFoundException;
import com.capgemini.lms.service.SuggestedBooksService;
import com.capgemini.lms.repository.SuggestedBooksRepository;

@Service
public class SuggestedBooksServiceImpl implements SuggestedBooksService {
	
	@Autowired
	SuggestedBooksRepository suggestedBooksRepo;

	@Override
	public int suggestBooks(List<Books> bookList) throws BookNotFoundException {
		try {
			suggestedBooksRepo.save(new SuggestedBooks());
		}catch(Exception e) {
			throw new BookNotFoundException("The passed object cannot be null");
		}
		return 0;
		
		
	}

	@Override
	public int updateSuggestedBookStatus(SuggestedBooks book) throws BookNotFoundException {
		try {
			suggestedBooksRepo.save(book);
		}catch(Exception e) {
            throw new BookNotFoundException("The passed object cannot be null.");
        }
		return 0;
		
	}

	@Override
	public int deleteSuggestedBooks(int id) throws BookNotFoundException {
		try {
			suggestedBooksRepo.deleteById(id);
		} catch (Exception e) {
			throw new BookNotFoundException("The object cannot be null");
		}
		return id;
		
	}

	@Override
	public SuggestedBooks viewSuggestedBookDetails(int id) throws BookNotFoundException {
		Optional findById = Optional.empty();
		if(findById.isPresent()) {
			return (SuggestedBooks) findById.get();
		}
		else {
			throw new BookNotFoundException("Reader with id :" + id + "doesn't exists");
		}
	
	}

	@Override
	public List<SuggestedBooks> viewSuggestedBooksList() {
		
		return (List<SuggestedBooks>) suggestedBooksRepo.findAll();
	}

	

}
