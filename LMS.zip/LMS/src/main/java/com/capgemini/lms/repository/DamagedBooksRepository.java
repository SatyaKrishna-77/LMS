package com.capgemini.lms.repository;
import com.capgemini.lms.entities.*;
import org.springframework.data.repository.CrudRepository;
public interface DamagedBooksRepository extends CrudRepository<DamagedBooks,Integer>{

	void save(Books bookid);
}
