package com.capgemini.lms.entities;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import java.util.Date;
@Entity
@Table(name = "books_order")

public class BooksOrder {
	
		@Id
		@Column(name = "order_id")
		@GeneratedValue(strategy = GenerationType.AUTO)
		private int orderId;
		//@Column(name = "books")
		@OneToOne(fetch = FetchType.EAGER)
		private Books books;
		//@Column(name = "publishers")
		//private Publishers publishers;
		@Column(name = "quantity")
		private int quantity;
		@Column(name = "order_date")
		private Date orderDate;
		@Column(name = "order_status")
		private String orderStatus;
		public BooksOrder() {
			
		}
	
		
		
		public BooksOrder(int orderId, Books books, int quantity, Date orderDate, String orderStatus)
				{
			super();
			this.orderId = orderId;
			this.books = books;
			//this.publishers = publishers;
			this.quantity = quantity;
			this.orderDate = orderDate;
			this.orderStatus = orderStatus;
				}



		public int getOrderId() {
			return orderId;
		}
		
			public void setOrderId(int orderId) {
			this.orderId = orderId;
			}
		public Books getBooks() {
			return books;
		}
		public void setBooks(Books books) {
			this.books = books;
		}
		/*public Publishers getPublishers() {
			return publishers;
		}
		public void setPublishers(Publishers publishers) {
			this.publishers = publishers;
		}*/
		public int getQuantity() {
			return quantity;
		}
		public void setQuantity(int quantity) {
			this.quantity = quantity;
		}
		public Date getOrderDate() {
			return orderDate;
		}
		public void setOrderDate(Date orderDate) {
			this.orderDate = orderDate;
		}
		public String getOrderStatus() {
			return orderStatus;
		}
		public void setOrderStatus(String orderStatus) {
			this.orderStatus = orderStatus;
		}
		
		
	   // public String toString() {
			
		//return "BooksOrder [order_id=" + orderId + ",books=" + books + ",publishers=" + publishers+",quantity="+quantity+",order_date =" + orderDate+",order_status = "+OrderStatus+ "]";
					
		} 
		
	


