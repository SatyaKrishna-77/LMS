package com.capgemini.lms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.capgemini.lms.entities.Author;

public interface AuthorRepository extends CrudRepository<Author, Integer>{

	//int getAuthorDeatils(Author author);

	//Author viewAuthorById(int id);

	//int updateAuthorDetails(Author author);
	@Query(value="select * from pizza", nativeQuery=true)
	List<Author> getAll();

	

}
