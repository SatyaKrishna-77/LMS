package com.capgemini.lms.entities;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;


@Entity  
@Table(name = "books_issued")
public class BooksIssued {
	    @Id
		@Column(name = "issue_id")
		@GeneratedValue(strategy = GenerationType.AUTO)
		private int issueId;
		//@Column(name = "users")
		//private Users users;
		//@Column(name = "books")
		//private List<Books> books;
		@Column(name = "issue_date")
		private Date issueDate;
		@Column(name = "quantity")
		private int quantity;
		@Column(name = "due_date")
		private Date dueDate;
		public BooksIssued() {
			
		}
		
		
		
		public BooksIssued(int issueId, Date issueDate, int quantity, Date dueDate) {
			super();
			this.issueId = issueId;
			//this.users = users;
			//this.books = books;
			this.issueDate = issueDate;
			this.quantity = quantity;
			this.dueDate = dueDate;
		}
		public int getIssueId() {
			return issueId;
		}
		public void setIssueId(int issueId) {
			this.issueId = issueId;
		}
		/*public Users getUsers() {
			return users;
		}
		public void setUsers(Users users) {
			this.users = users;
		}
		public List<Books> getBooks() {
			return books;
		}
		public void setBooks(List<Books> books) {
			this.books = books;
		}*/
		public Date getIssueDate() {
			return issueDate;
		}
		public void setIssueDate(Date issueDate) {
			this.issueDate = issueDate;
		}
		public int getQuantity() {
			return quantity;
		}
		public void setQuantity(int quantity) {
			this.quantity = quantity;
		}
		public Date getDueDate() {
			return dueDate;
		}
		public void setDueDate(Date dueDate) {
			this.dueDate = dueDate;
		}
		
		/*@Override
	    public String toString() {
			
		return "BooksIssued [issue_id=" + issueId + ", users=" + users + ",books=" +books+",issue_date="+issueDate+",quantity =" +quantity+",due_date = "+dueDate+ "]";
					
		}*/
		
		
	}


